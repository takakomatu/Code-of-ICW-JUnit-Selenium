import static org.openqa.selenium.support.ui.ExpectedConditions.*;

import java.io.File;

import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class fruitsPickingTest1 {

	@Test
	public void test() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("小松");
        driver.findElement(By.name("first")).sendKeys("琢昂");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2019-01-19");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("Takaaki.Komatsu@ibm.com");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("08067063476");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
//        File screenfile = ((Screenshot)driver).getScreenshotAs(file);
        File sfile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        System.out.println(sfile);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);
        File sfile2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        System.out.println(sfile2);
        driver.findElement(By.xpath("//input[@value='予約内容を送信する']")).click();
        Sleep.sleep(2.5);
        File sfile3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        System.out.println(sfile3);

//        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//        driver.get(baseUrl + "/sample.html");
//        driver.switchTo().defaultContent();
        TakesScreenshot ts = (TakesScreenshot) new Augmenter().augment(driver);
//        FileUtils.moveFile(ts.getScreenshotAs(OutputType.FILE), new File("c:\\temp\\img-"+ System.currentTimeMillis() +".png"));
        driver.quit();
	}
	@Test
	public void test2() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("");
        driver.findElement(By.name("first")).sendKeys("琢昂");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2019-01-19");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("Takaaki.Komatsu@ibm.com");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("08067063476");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);
        Wait<WebDriver> wait = new WebDriverWait(driver,10);
        Alert alert = wait.until(alertIsPresent());
        alert = driver.switchTo().alert();
        Sleep.sleep(2.5);
        alert.accept();//ダイアログ「OK」ボタン押下
        Sleep.sleep(3.5);

        driver.quit();
	}
	@Test
	public void test3() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("小松");
        driver.findElement(By.name("first")).sendKeys("");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2019-01-19");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("Takaaki.Komatsu@ibm.com");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("08067063476");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);
        Wait<WebDriver> wait = new WebDriverWait(driver,10);
        Alert alert = wait.until(alertIsPresent());
        alert = driver.switchTo().alert();
        Sleep.sleep(2.5);
        alert.accept();//ダイアログ「OK」ボタン押下
        Sleep.sleep(3.5);

        driver.quit();
	}

	@Test
	public void test4() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("小松");
        driver.findElement(By.name("first")).sendKeys("琢昂");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2017-12-25");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("Takaaki.Komatsu@ibm.com");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("08067063476");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);

        driver.quit();
	}

	@Test
	public void test5() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("小松");
        driver.findElement(By.name("first")).sendKeys("琢昂");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2019-01-19");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("08067063476");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);
        Wait<WebDriver> wait = new WebDriverWait(driver,10);
        Alert alert = wait.until(alertIsPresent());
        alert = driver.switchTo().alert();
        Sleep.sleep(2.5);
        alert.accept();//ダイアログ「OK」ボタン押下
        Sleep.sleep(3.5);

        driver.quit();
	}

	@Test
	public void test6() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("小松");
        driver.findElement(By.name("first")).sendKeys("琢昂");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2019-01-19");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("Takaaki.Komatsu@ibm.com");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);
        Wait<WebDriver> wait = new WebDriverWait(driver,10);
        Alert alert = wait.until(alertIsPresent());
        alert = driver.switchTo().alert();
        Sleep.sleep(2.5);
        alert.accept();//ダイアログ「OK」ボタン押下
        Sleep.sleep(3.5);

        driver.quit();
	}

	@Test
	public void test7() throws InterruptedException {
    	System.setProperty("webdriver.chrome.driver", "./driver/chromedriver");
        // chmod +x chromedriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/ICWT2/pickingReserve");
//        driver.findElement(By.partialLinkText("ご予約はこちら")).click();
//
//        Wait<WebDriver> wait = new WebDriverWait(driver,10);

        driver.findElement(By.name("last")).sendKeys("");
        driver.findElement(By.name("first")).sendKeys("");
        Sleep.sleep(0.5);
        driver.findElement(By.name("number")).sendKeys("3");
        Sleep.sleep(0.5);
        driver.findElement(By.name("year")).sendKeys("2017-12-25");
        Sleep.sleep(0.5);
        driver.findElement(By.name("hour")).sendKeys("14");
        driver.findElement(By.name("minute")).sendKeys("30");
        Sleep.sleep(0.5);
        driver.findElement(By.name("email")).sendKeys("");
        Sleep.sleep(0.5);
        driver.findElement(By.name("tel")).sendKeys("");
        Sleep.sleep(0.5);
        driver.findElement(By.name("bikou")).sendKeys("よろしくお願いします。");
        Sleep.sleep(2.5);
        driver.findElement(By.xpath("//input[@value='送信']")).click();
        Sleep.sleep(2.5);

        driver.quit();
	}
}
