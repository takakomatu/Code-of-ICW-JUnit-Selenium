
public class Main {

	public static void main(String[] args) throws InterruptedException {
		fruitsPickingTest1 instance = new fruitsPickingTest1();
		instance.test();
		System.out.println(1);
		instance.test2();
		System.out.println(2);
		instance.test3();
		System.out.println(3);
		instance.test4();
		System.out.println(4);
		instance.test5();
		System.out.println(5);
		instance.test6();
		System.out.println(6);
		instance.test7();
	}

}
