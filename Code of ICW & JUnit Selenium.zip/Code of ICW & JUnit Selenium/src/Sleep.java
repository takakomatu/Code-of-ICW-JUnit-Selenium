
public class Sleep {
	public static void sleep(double n) throws InterruptedException{
		int s = (int) n*1000; // 10000= 1second
		Thread.sleep(s);
	}
}
